# VPCS
This is not the official VPCS repository and used only by GNS3 team to develop patch before sending them
to the VPCS team.
The latest VPCS release can be downloaded from http://sourceforge.net/projects/vpcs/files/

## Update git from offical SVN
git svn fetch
git svn rebase
